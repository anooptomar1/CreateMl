#!/usr/bin/swift

import Foundation
import CreateML

let trainingDir = URL(fileURLWithPath: "/Users/Shared/ML/Training")
let testingDir = URL(fileURLWithPath: "/Users/Shared/ML/Testing")

let trainingDataSet = MLImageClassifier.DataSource.labeledDirectories(at: trainingDir)
let testingDataSet = MLImageClassifier.DataSource.labeledFiles(at: testingDir)

let model = try! MLImageClassifier(trainingData: trainingDataSet)
let evaluation = model.evaluation(on: testingDataSet)

try!  model.write(toFile: "/Users/Shared/ML/Output/foodClassifier \(Date().timeIntervalSince1970).mlmodel")

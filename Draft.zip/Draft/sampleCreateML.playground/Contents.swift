//
//import Foundation
//import CreateML
//
//let trainingDir = URL(fileURLWithPath: "/Users/Shared/ML/Training")
//let testingDir = URL(fileURLWithPath: "/Users/Shared/ML/Testing")
//
//let params = MLImageClassifier.ModelParameters(featureExtractor: .scenePrint(revision: 1), validationData: .labeledDirectories(at: testingDir), maxIterations: 15, augmentationOptions: [MLImageClassifier.ImageAugmentationOptions.crop])
//
//let classifier = try! MLImageClassifier(trainingData: .labeledDirectories(at: trainingDir), parameters: params)
//
//try! classifier.write(to: URL(fileURLWithPath: "/Users/Shared/ML/Output/foodModel_\(Date().timeIntervalSince1970).mlmodel"), metadata: MLModelMetadata(author: "DevTechie Interactive", shortDescription: "Image classifier from DevTechie Interactive.", license: "MIT", version: "1.0", additional: nil))

//let model = try! MLImageClassifier(trainingData: .labeledDirectories(at: trainingDir))

//let evaluation = model.evaluation(on: .labeledDirectories(at: testingDir))

//try! model.write(toFile: "/Users/Shared/ML/Output/foodModel_\(Date().timeIntervalSince1970).mlmodel")



//import CreateMLUI
//
//let builder = MLImageClassifierBuilder()
//builder.showInLiveView()

//import Foundation
//import CreateML
//
//let data = try MLDataTable(contentsOf: URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/hamSpam.json"))
//let (trainingSet, testingSet) = data.randomSplit(by: 0.8, seed: 5)
//let spamHamClassifier = try MLTextClassifier(trainingData: trainingSet, textColumn: "text", labelColumn: "label")
//
//let trainingAccuracy = (1.0 - spamHamClassifier.trainingMetrics.classificationError) * 100
//let validationAccuracy = (1.0 - spamHamClassifier.validationMetrics.classificationError) * 100
//
//let evaluationMetrics = spamHamClassifier.evaluation(on: testingSet)
//let evaluationAccuracy = (1.0 - evaluationMetrics.classificationError) * 100
//
//let metadata = MLModelMetadata(author: "DevTechie Interactive", shortDescription: "Text classifier created by DevTechie Interactive for spam-ham classification", license: "MIT", version: "1.0", additional: nil)
//try spamHamClassifier.write(toFile: "/Users/Shared/ML/TextClassifier/spamHamClassifier.mlmodel", metadata: metadata)
//
//
//// test the model
//import NaturalLanguage
//let spamClassifier = try NLModel(mlModel: spamHamClassifier.model)
//spamClassifier.predictedLabel(for: "YOYOYO what's up wanna hangout?")

//---------------
//import Foundation
//import CreateML
//
//let dataUrl = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/SentimentData")
//let classifier = try MLTextClassifier(trainingData: MLTextClassifier.DataSource.labeledDirectories(at: dataUrl))
//
//import NaturalLanguage
//let sentiClassifier = try NLModel(mlModel: classifier.model)
//sentiClassifier.predictedLabel(for: "This is great")

// ----------------------

// Example 1
//
//import Foundation
//import CreateML
//
//let data = [
//    "spam": [
//        "Free entry in 2 a wkly comp to win FA Cup final tkts 21st May 2005. Text FA to 87121 to receive entry question(std txt rate)T&C's apply 08452810075over18's",
//        "FreeMsg Hey there darling it's been 3 week's now and no word back! I'd like some fun you up for it still? Tb ok! XxX std chgs to send, �1.50 to rcv",
//        "WINNER!! As a valued network customer you have been selected to receivea �900 prize reward! To claim call 09061701461. Claim code KL341. Valid 12 hours only.",
//        "Had your mobile 11 months or more? U R entitled to Update to the latest colour mobiles with camera for Free! Call The Mobile Update Co FREE on 08002986030",
//        "SIX chances to win CASH! From 100 to 20,000 pounds txt> CSH11 and send to 87575. Cost 150p/day, 6days, 16+ TsandCs apply Reply HL 4 info"],
//
//    "ham": [
//        "Go until jurong point, crazy.. Available only in bugis n great world la e buffet... Cine there got amore wat...",
//        "Ok lar... Joking wif u oni...",
//        "U dun say so early hor... U c already then say...",
//        "Nah I don't think he goes to usf, he lives around here though",
//        "Even my brother is not like to speak with me. They treat me like aids patent."]]
//
//let classifier = try MLTextClassifier(trainingData: data)
//
//
//import NaturalLanguage
//
//let spamClassifier = try NLModel(mlModel: classifier.model)
//spamClassifier.predictedLabel(for: "hi")
//spamClassifier.predictedLabel(for: "WINNER: you are a winner")

//---------------
// another example
//
//import Foundation
//import CreateML
//import NaturalLanguage
//
//let dataUrl = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/SentimentData")
//let data = MLTextClassifier.DataSource.labeledDirectories(at: dataUrl)
//// CRF
//let params =  MLTextClassifier.ModelParameters.init(validationData: [:], algorithm: MLTextClassifier.ModelAlgorithmType.crf(revision: 1), language: NLLanguage.english)
//// MaxEnt
////let params = MLTextClassifier.ModelParameters.init(validationData: [:], algorithm: MLTextClassifier.ModelAlgorithmType.maxEnt(revision: 1), language: NLLanguage.english)
//
//let classifier =  MLTextClassifier(trainingData: data, parameters: params)
//
//// testing trained model
//let sentiClassifier =  NLModel(mlModel: classifier.model)
//sentiClassifier.predictedLabel(for: "Not good")
//sentiClassifier.predictedLabel(for: "Good")
//
//// classifier's prediction example
//classifier.prediction(from: "Not good")
//classifier.predictions(from: ["Good", "Not good"])
//
//// training metrics
//classifier.trainingMetrics.classificationError
//classifier.validationMetrics.classificationError
//
//classifier.evaluation(on: ["Positive": ["Good","Great"],
//                           "Negative": ["Bad", "Worst"]]).confusion


//import CreateML
//import Foundation
//
//// loading data from json file
//let dataUrl = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/hamSpam.json")
//let table = try MLDataTable(contentsOf: dataUrl)
//
//// loading data from dictionary
//let data: [String: MLDataValueConvertible] = [
//    "title": ["Alice in Wonderland", "Hamlet", "Treasure Island", "Peter Pan"],
//    "author": ["Lewis Carroll", "William Shakespeare", "Robert L. Stevenson", "J. M. Barrie"],
//    "pageCount": [124, 98, 280, 94],
//    "genre": ["Fantasy", "Drama", "Adventure", "Fantasy"]
//]
//
//let newTable = try MLDataTable(dictionary: data)
//
//// loading from csv
//let csvUrl = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/iris.csv")
//var irisTable = try MLDataTable(contentsOf: csvUrl)
//
//// describe table
//
//// get number of rows and columns in the data table
//irisTable.size
//
//// get column names
//irisTable.columnNames
//
//// get column types
//irisTable.columnTypes
//
//// get text representation of table
//irisTable.description
//
//// data table shown in playground
//irisTable.playgroundDescription
//
//// get column by name
//irisTable["sepal_length"]
//irisTable["species"]
//
//// filter out rows
//let setosaFilter = irisTable["species", String.self]! != "setosa"
//
//let noSetosaTable = irisTable[setosaFilter]
//
//// filer out rows example 2
//let speciesColumn = irisTable["species"]
//let onlySetosa = irisTable[speciesColumn == "setosa"]
//let noSetosa = irisTable[speciesColumn != "setosa"]
//
//// split data randomly
//let (training, test) =  irisTable.randomSplit(by: 0.75, seed: 5)
//
//training.rows.count
//
//test.rows.count
//
//// derive new column from existing table data
//// and add new column to the table
//
//let columnName = "desc"
//
//let derivedColumn = irisTable.map { row -> String in
//    return String(format: "%@ %.1f", row["species"]!.stringValue!, row["sepal_width"]!.doubleValue!)
//}
//
//irisTable.addColumn(derivedColumn, named: columnName)
//
//// remove column from table
//irisTable.removeColumn(named: columnName)
//
//// get top rows
//print("------------TOP 5---------------")
//irisTable.rows.prefix(5).forEach { row in
//    print(row)
//}
//
//// get last rows
//print("------------BOTTOM 5---------------")
//irisTable.rows.suffix(5).forEach { row in
//    print(row)
//}
//
//// drop missing values
//irisTable.dropMissing()
//
//// drop duplicate values
//irisTable.dropDuplicates()
//
//// fill missing values
//var i = 0
//let newDerivedColumn = irisTable.map { row -> String? in
//    i = i + 1
//    if i % 2 == 0 {
//        return String(format: "%@ %.1f", row["species"]!.stringValue!, row["sepal_width"]!.doubleValue!)
//    }
//    return nil
//}
//irisTable.addColumn(newDerivedColumn, named: "desc_missing")
//irisTable.fillMissing(columnNamed: "desc_missing", with: MLDataValue.string("-----"))

//// -------- CLassifier vs Regressor -------------
//import CreateML
//import Foundation
//
////let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/winequality-white.csv")
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/winequality-red.csv")
//// load data into data table
//let table = try MLDataTable(contentsOf: dataURL)
//// data split to training and test
//let (trainingSet, testSet) = table.randomSplit(by: 0.8, seed: 4)
//// classification
//let classifier = try MLClassifier(trainingData: trainingSet, targetColumn: "quality")
//// evaluation
//let evaluation = classifier.evaluation(on: testSet)
//print(evaluation)

//// ------------- Regressor example ------------------

//import Foundation
//import CreateML
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/boston.csv")
//
//let table = try MLDataTable(contentsOf: dataURL)
//
//let (trainingSet, testSet) = table.randomSplit(by: 0.8, seed: 5)
//
//let regressor = try MLRegressor(trainingData: trainingSet, targetColumn: "PRICE")
//
//let evaluate = regressor.evaluation(on: testSet)
//
//print(evaluate.rootMeanSquaredError)

// -------------- MLDecisionTreeClassifier ------------------------

//import Foundation
//import CreateML
//
//let trainingURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/Titanic/train.csv")
//let testURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/Titanic/test.csv")
//
//var trainingTable = try MLDataTable(contentsOf: trainingURL)
//var testTable = try MLDataTable(contentsOf: testURL)
//
//// drop ticket column because we will not need that during this prediction
//trainingTable.removeColumn(named: "Ticket")
//testTable.removeColumn(named: "Ticket")
//
//// remove data where age is missing for better predictions
//let ageColumn = trainingTable["Age", Double.self]!
//let ageMask = ageColumn.mapMissing {
//    return $0 != nil
//}
//let newTrainingTable = trainingTable[ageMask]
//
//// training classifier
//let titanicSurvivalClassifier = try MLDecisionTreeClassifier(trainingData: newTrainingTable, targetColumn: "Survived")
//
//let predictions = try titanicSurvivalClassifier.predictions(from: testTable)
//
//let passengersData = testTable["PassengerId", Int.self]!
//var predictionsTable = MLDataTable()
//predictionsTable.addColumn(passengersData, named: "PassengerId")
//predictionsTable.addColumn(predictions, named: "Survival_Prediction")
//predictionsTable.rows.forEach { row in
//    let survived = row["Survival_Prediction"]!.intValue! == 1 ? "survived." : "didn't survive."
//    print("Passender id: \(row["PassengerId"]!.intValue!) \(survived)")
//}

// ------------------ MLLogisticRegressionClassifier -----------------------
//import CreateML
//import Foundation
//
//let trainingURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/Titanic/train.csv")
//let testURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/Titanic/test.csv")
//
//var trainingTable = try MLDataTable(contentsOf: trainingURL)
//var testTable = try MLDataTable(contentsOf: testURL)
//
//trainingTable = trainingTable.dropMissing()
//testTable = testTable.dropMissing()
//
//let trainingParams = MLLogisticRegressionClassifier.ModelParameters(validationData: trainingTable, maxIterations: 100, l1Penalty: 8.0, l2Penalty: 0.0, stepSize: 4.0, convergenceThreshold: 0.01, featureRescaling: true)
//
//let classifier = try MLLogisticRegressionClassifier(trainingData: trainingTable, targetColumn: "Survived", featureColumns: nil, parameters: trainingParams)
//
//// validation metrics
//let metrics = classifier.validationMetrics
//let evaluation = classifier.evaluation(on: testTable)
//
//print("------------Metrics------------")
//print(metrics)
//
//print("--------------Evaluation Precision Recall-------")
//print(evaluation.precisionRecall)

// ==================== MLRandomForestClassifier ===================
//import CreateML
//import Foundation
//
//// data url
//let dataUrl = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/Mushrooms.csv")
//// data into data table
//let dataTable = try MLDataTable(contentsOf: dataUrl)
//// split data into training and test set
//let (trainingSet, testSet) = dataTable.randomSplit(by: 0.8)
//// classification
//let randomForestClassfier = try MLRandomForestClassifier(trainingData: trainingSet, targetColumn: "class")
//// predictions
//let predictions = try randomForestClassfier.predictions(from: testSet)
//// prediction table
//var predictionTable = testSet
//predictionTable.addColumn(predictions, named: "predicted_class")
//// print predictions
//predictionTable.rows.forEach { row in
//    let habitat = row["habitat", String.self]!
//    let predictedClass = row["predicted_class", String.self]!
//    let actualClass = row["class", String.self]!
//    print("Habitat: \(habitat), Predicted class: \(predictedClass), Actual class: \(actualClass)")
//}

// ==================== MLBoostedTreeClassifier ===================
//import CreateML
//import Foundation
//// get data url
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/iris.csv")
//// load data into data table
//let table = try MLDataTable(contentsOf: dataURL)
//// split data into test and training
//var (trainingSet, testSet) = table.randomSplit(by: 0.8)
//// remove duplicates
//trainingSet = trainingSet.dropDuplicates()
//testSet = testSet.dropDuplicates()
//// remove missing values
//trainingSet = trainingSet.dropMissing()
//testSet = testSet.dropMissing()
//// train classifier using boosted tree classifier
//let boostedTreeClassifier = try MLBoostedTreeClassifier(trainingData: trainingSet, targetColumn: "species")
//// evaluate
//let evaluate = boostedTreeClassifier.evaluation(on: testSet)
//// get predictions
//let predictions = try boostedTreeClassifier.predictions(from: testSet)
//// create table to print predictions
//var predictionTable = testSet
//predictionTable.addColumn(predictions, named: "predicted_species")
//// print row
//predictionTable.rows.forEach { row in
//    row.forEach({ (key, value) in
//        print("Key: \(key), Value: \(value)")
//    })
//    print("================new row===============")
//}

// ==================== MLSupportVectorClassifier ===================
//import CreateML
//import Foundation
//
//// load data
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/adult-income.csv")
//
//// load data table
//let table = try MLDataTable(contentsOf: dataURL)
//
//// split data into training and test
//var (trainingSet, testSet) = table.randomSplit(by: 0.8)
//
//// remove dups
//trainingSet.dropDuplicates()
//testSet.dropDuplicates()
//
//// remove missing
//trainingSet.dropMissing()
//testSet.dropMissing()
//
//// model params
//let params = MLSupportVectorClassifier.ModelParameters.init(validationData: trainingSet, maxIterations: 100, penalty: 8.0, convergenceThreshold: 0.01, featureRescaling: true)
//
//// build classfier
//let svmClassifier = try MLSupportVectorClassifier(trainingData: trainingSet, targetColumn: "income-level", featureColumns: nil, parameters: params)
//
//
//// validation metrics
//let metrics = svmClassifier.validationMetrics
//let evaluation = svmClassifier.evaluation(on: testSet)
//
//print("------------Metrics------------")
//print(metrics)
//
//// predictions
//let predictions = try svmClassifier.predictions(from: testSet)
//var predictionTable = testSet
//predictionTable.addColumn(predictions, named: "predicted_income")
//// print row
//predictionTable.rows.forEach { row in
//    row.forEach({ (key, value) in
//        print("Key: \(key), Value: \(value)")
//    })
//    print("================new row===============")
//}

//

//// ==================== MLLinearRegressor ===================
//import Foundation
//import CreateML
//
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/sat.csv")
//let table = try MLDataTable(contentsOf: dataURL)
//let (trainingData, testData) = table.randomSplit(by: 0.8)
//// A regression model that uses L1 regularization/ l1 penalty technique is called Lasso Regression and model which uses L2 regularization/ l2 penalty is called Ridge Regression
//// Ridge regression adds “squared magnitude” of coefficient as penalty term to the loss function.
//// Lasso Regression (Least Absolute Shrinkage and Selection Operator) adds “absolute value of magnitude” of coefficient as penalty term to the loss function
//// The key difference between these techniques is that Lasso shrinks the less important feature’s coefficient to zero thus, removing some feature altogether. So, this works well for feature selection in case we have a huge number of features.
//// stepSize: corresponds to learning rate, to understand better google gradient decent
////  The convergence threshold is the maximum percentage of pixels whose cluster assignments can go unchanged between iterations.
//// Feature scaling is a method used to standardize the range of independent variables or features of data. 
//let params = MLLinearRegressor.ModelParameters(validationData: trainingData, maxIterations: 100, l1Penalty: 8.0, l2Penalty: 0, stepSize: 4, convergenceThreshold: 0.01, featureRescaling: true)
//
//let classifier = try MLLinearRegressor(trainingData: trainingData, targetColumn: "univ_GPA", featureColumns: nil, parameters: params)
//let evaluation = classifier.evaluation(on: testData)
//print(evaluation.rootMeanSquaredError)
//print(evaluation.maximumError)
//let predictions = try classifier.predictions(from: testData)
//var predictionTable = testData
//
//predictionTable.addColumn(predictions, named: "predicted_GPA")
//predictionTable.rows.forEach { row in
//    row.forEach({ (key, value) in
//        print("(\(key), \(value))")
//
//    })
//    print("=====================")
//}

// ==================== MLDecisionTreeRegressor ===================
//import Foundation
//import CreateML
//
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/sat.csv")
//let table = try MLDataTable(contentsOf: dataURL)
//let (trainingData, testData) = table.randomSplit(by: 0.8)
//let params = MLDecisionTreeRegressor.ModelParameters.init(validationData: trainingData, maxDepth: 6, minLossReduction: 0, minChildWeight: 10, randomSeed: 0)
//let classifier = try MLDecisionTreeRegressor(trainingData: trainingData, targetColumn: "univ_GPA", featureColumns: nil, parameters: params)
//let evaluation = classifier.evaluation(on: testData)
//print(evaluation.rootMeanSquaredError)
//print(evaluation.maximumError)
//let predictions = try classifier.predictions(from: testData)
//var predictionTable = testData
//
//predictionTable.addColumn(predictions, named: "predicted_GPA")
//predictionTable.rows.forEach { row in
//    row.forEach({ (key, value) in
//        print("(\(key), \(value))")
//
//    })
//    print("=====================")
//}

// ==================== MLRandomForestRegressor ===================
//import Foundation
//import CreateML
//
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/bike_sharing_hour.csv")
//let table = try MLDataTable(contentsOf: dataURL)
//let (trainingData, testData) = table.randomSplit(by: 0.8)
//let classifier = try MLRandomForestRegressor(trainingData: trainingData, targetColumn: "cnt")
//let evaluation = classifier.evaluation(on: testData)
//print(evaluation.rootMeanSquaredError)
//print(evaluation.maximumError)
//let predictions = try classifier.predictions(from: testData)
//var predictionTable = testData
//
//predictionTable.addColumn(predictions, named: "predicted_bike_count_per_hour")
//predictionTable.rows.forEach { row in
//    row.forEach({ (key, value) in
//        print("(\(key), \(value))")
//
//    })
//    print("=====================")
//}

// ==================== MLBoostedTreeRegressor ===================
//import Foundation
//import CreateML
//
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/bike_sharing_day.csv")
//let table = try MLDataTable(contentsOf: dataURL)
//let (trainingData, testData) = table.randomSplit(by: 0.8)
//// maxDepth: Maximum depth of a tree. Increasing this value will make the model more complex and more likely to overfit. 0 indicates no limit.
//// maxIteration: number of iterations to train model
//// minLossReduction: Minimum loss reduction required to make a further partition on a leaf node of the tree. The larger the value is, the more conservative the algorithm will be.
//// minChildWeight: Minimum sum of instance weight (hessian) needed in a child. If the tree partition step results in a leaf node with the sum of instance weight less than min_child_weight, then the building process will give up further partitioning. In linear regression task, this simply corresponds to minimum number of instances needed to be in each node. The larger min_child_weight is, the more conservative the algorithm will be.
//// randomSeed: Random number seed.
//// stepSize: Step size shrinkage used in update to prevents overfitting. Its also known as learning rate. After each boosting step, we can directly get the weights of new features, and stepSize shrinks the feature weights to make the boosting process more conservative.
//// earlyStoppingRound: Early stopping support in Gradient Boosting enables us to find the least number of iterations which is sufficient to build a model that generalizes well to unseen data.
//// rowSubSample: Subsample ratio of the training instances. Setting it to 0.5 means that regressor would randomly sample half of the training data prior to growing trees. and this will prevent overfitting. Subsampling will occur once in every boosting iteration.
//// columnSubSample: Subsample ratio of columns when constructing each tree. Subsampling will occur once in every boosting iteration
//let params = MLBoostedTreeRegressor.ModelParameters(validationData: trainingData, maxDepth: 6, maxIterations: 100, minLossReduction: 0, minChildWeight: 1, randomSeed: 0, stepSize: 0.3, earlyStoppingRounds: 50, rowSubsample: 0.5, columnSubsample: 1)
////let classifier = try MLBoostedTreeRegressor(trainingData: trainingData, targetColumn: "cnt")
//let classifier = try MLBoostedTreeRegressor(trainingData: trainingData, targetColumn: "cnt", featureColumns: nil, parameters: params)
//let evaluation = classifier.evaluation(on: testData)
//print(evaluation.rootMeanSquaredError)
//print(evaluation.maximumError)
//let predictions = try classifier.predictions(from: testData)
//var predictionTable = testData
//
//predictionTable.addColumn(predictions, named: "predicted_bike_count_per_day")
//predictionTable.rows.forEach { row in
//    row.forEach({ (key, value) in
//        print("(\(key), \(value))")
//
//    })
//    print("=====================")
//}

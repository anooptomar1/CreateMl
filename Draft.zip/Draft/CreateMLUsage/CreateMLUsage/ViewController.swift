//
// ViewController
// CreateMLUsage
//
// Created by DevTechie Interactive on 10/10/18.
// Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit
import Vision
import CoreML

class ViewController: UIViewController {
    
    lazy var classificationRequest: VNCoreMLRequest = {
        let model = try! VNCoreMLModel(for: ImageClassifier().model)
        let request = VNCoreMLRequest(model: model, completionHandler: { (request, error) in
            self.processImageForClassification(for: request, error: error)
        })
        request.imageCropAndScaleOption = .centerCrop
        return request
    }()
    
    @IBOutlet weak var imageV: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func didPressProcessButton(_ sender: UIButton) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
    }
    
    func processImageForClassification(for request: VNRequest, error: Error?) {
        guard let results = request.results, let classifications = results as? [VNClassificationObservation] else {
            print("Unable to classify")
            return
        }
        
        if classifications.isEmpty {
            print("No results")
        } else {
            let topClassifications = classifications.prefix(2)
            let desc = topClassifications.map { classification in
                return String(format: " (%.2f) %@", classification.confidence, classification.identifier)
            }
            print(desc)
        }
        
    }
    
    func performClassification(for image: UIImage) {
        guard let ciImage = CIImage(image: image) else {
            print("Unable to convert image to CIImage")
            return
        }
        DispatchQueue.global(qos: DispatchQoS.QoSClass.userInitiated).async {
            let handler = VNImageRequestHandler(ciImage: ciImage, options: [:])
            do{
                try handler.perform([self.classificationRequest])
            }
            catch {
                print(error.localizedDescription)
            }
        }
    }
    
}

extension ViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            picker.dismiss(animated: true, completion: nil)
            self.imageV.image = image
            self.performClassification(for: image)
        }
    }
}

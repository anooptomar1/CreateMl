//import CreateMLUI
//
//let builder = MLImageClassifierBuilder()
//builder.showInLiveView()

// v1

//import Cocoa
//import CreateML
//
//let trainingDir = URL(fileURLWithPath: "/Users/Shared/ML/Training")
//let testingDir = URL(fileURLWithPath: "/Users/Shared/ML/Testing")
//
//let trainingDataSet = MLImageClassifier.DataSource.labeledDirectories(at: trainingDir)
//let testingDataSet = MLImageClassifier.DataSource.labeledFiles(at: testingDir)
//
//let model = try! MLImageClassifier(trainingData: trainingDataSet)
//let evaluation = model.evaluation(on: testingDataSet)
//
//try!  model.write(toFile: "/Users/Shared/ML/Output/foodClassifier \(Date().timeIntervalSince1970).mlmodel")

//v2

//import Foundation
//import CreateML
//
//let trainingDir = URL(fileURLWithPath: "/Users/Shared/ML/Training")
//let testingDir = URL(fileURLWithPath: "/Users/Shared/ML/Testing")
//
//let params = MLImageClassifier.ModelParameters(featureExtractor: MLImageClassifier.FeatureExtractorType.scenePrint(revision: 1), validationData: MLImageClassifier.DataSource.labeledDirectories(at: testingDir), maxIterations: 15, augmentationOptions: MLImageClassifier.ImageAugmentationOptions.crop)
//
//let classifier = try! MLImageClassifier(trainingData: MLImageClassifier.DataSource.labeledDirectories(at: trainingDir), parameters: params)
//
//// save the coreml file
//let metadata = MLModelMetadata(author: "DevTechie Interactive", shortDescription: "Image classifier from DevTechie Interactive", license: "MIT", version: "1.0", additional: nil)
//
//try! classifier.write(toFile: "/Users/Shared/ML/Output/foodClassifier \(Date().timeIntervalSince1970).mlmodel", metadata: metadata)


// MLTextClassifier
//import Foundation
//import CreateML
//
//let data = try MLDataTable(contentsOf: URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/hamSpam.json"))
//
//let (trainingSet, testingSet) = data.randomSplit(by: 0.8, seed: 5)
//
//let spamHamClassifier = try MLTextClassifier(trainingData: trainingSet, textColumn: "text", labelColumn: "label")
//
//let trainingAccuracy = (1.0 - spamHamClassifier.trainingMetrics.classificationError) * 100
//
//let validationAccuracy = (1.0 - spamHamClassifier.validationMetrics.classificationError) * 100
//
//let evaluation = spamHamClassifier.evaluation(on: testingSet)
//
//let evaluationAccuracy = (1.0 - evaluation.classificationError) * 100
//
//let metadata = MLModelMetadata(author: "DevTechie Interactive", shortDescription: "Text classifier for spam detection by DevTechie Interactive", license: "MIT", version: "1.0", additional: nil)
//
//try spamHamClassifier.write(toFile: "/Users/Shared/ML/TextClassifier/spam_ham_classifier.mlmodel", metadata: metadata)
//
//// test ml model
//
//import NaturalLanguage
//let spamClassifier = try NLModel(mlModel: spamHamClassifier.model)
//spamClassifier.predictedLabel(for: "XXXNewMovieClub click here>> http://wap. xxxmobilemovieclub.com?n=QJKGIGHJJGCBL")

// MLTextClassifier v2
//import Foundation
//import CreateML
//
//let dataUrl = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/SentimentData")
//let classifier = try MLTextClassifier(trainingData: MLTextClassifier.DataSource.labeledDirectories(at: dataUrl))
//
//import NaturalLanguage
//let sentiClassifier = try NLModel(mlModel: classifier.model)
//sentiClassifier.predictedLabel(for: "This is bad")

//-------------
// MLTextClassifier addtional examples

//import Foundation
//import CreateML
//import NaturalLanguage
//
//let data = [
//    "spam": [
//        "Free entry in 2 a wkly comp to win FA Cup final tkts 21st May 2005. Text FA to 87121 to receive entry question(std txt rate)T&C's apply 08452810075over18's",
//        "FreeMsg Hey there darling it's been 3 week's now and no word back! I'd like some fun you up for it still? Tb ok! XxX std chgs to send, �1.50 to rcv",
//        "WINNER!! As a valued network customer you have been selected to receivea �900 prize reward! To claim call 09061701461. Claim code KL341. Valid 12 hours only.",
//        "Had your mobile 11 months or more? U R entitled to Update to the latest colour mobiles with camera for Free! Call The Mobile Update Co FREE on 08002986030",
//        "SIX chances to win CASH! From 100 to 20,000 pounds txt> CSH11 and send to 87575. Cost 150p/day, 6days, 16+ TsandCs apply Reply HL 4 info"],
//
//    "ham": [
//        "Go until jurong point, crazy.. Available only in bugis n great world la e buffet... Cine there got amore wat...",
//        "Ok lar... Joking wif u oni...",
//        "U dun say so early hor... U c already then say...",
//        "Nah I don't think he goes to usf, he lives around here though",
//        "Even my brother is not like to speak with me. They treat me like aids patent."]]
//
//let classifier = try MLTextClassifier(trainingData: data)
//
//let spamClassifier = try NLModel(mlModel: classifier.model)
//spamClassifier.predictedLabel(for: "ok already")
//spamClassifier.predictedLabel(for: "WINNER: you are a winner")


// another example of text classification
//import Foundation
//import CreateML
//import NaturalLanguage
//
//let dataUrl = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/SentimentData")
//let data = MLTextClassifier.DataSource.labeledDirectories(at: dataUrl)
//
//// crf
////let params = MLTextClassifier.ModelParameters.init(validationData: [:], algorithm: MLTextClassifier.ModelAlgorithmType.crf(revision: 1), language: NLLanguage.english)
//
//// maxEnt
//let params = MLTextClassifier.ModelParameters.init(validationData: [:], algorithm: MLTextClassifier.ModelAlgorithmType.maxEnt(revision: 1), language: NLLanguage.english)
//
//
//let classifier = MLTextClassifier(trainingData: data, parameters: params)
//
//// testing model
//let sentiClassifier = NLModel(mlModel: classifier.model)
//sentiClassifier.predictedLabel(for: "Not good")
//sentiClassifier.predictedLabel(for: "Good")
//
//classifier.prediction(from: "No good")
//classifier.predictions(from: ["Not good", "Good"])
//
//(1.0 - classifier.trainingMetrics.classificationError) * 100
//(1.0 - classifier.validationMetrics.classificationError) * 100
//
//classifier.evaluation(on: [
//    "Positive": ["Good", "Great"],
//    "Negative": ["Bad", "Really bad"]]).confusion

//import CreateML
//import Foundation

//// load data from JSON
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/hamSpam.json")
//let table = try MLDataTable(contentsOf: dataURL)

//// load data from dictionary
//let data: [String: MLDataValueConvertible] = [
//    "title": ["Alice in Wonderland", "Hamlet", "Treasure Island", "Peter Pan"],
//    "author": ["Lewis Carroll", "William Shakespeare", "Robert L. Stevenson", "J. M. Barrie"],
//    "pageCount": [124, 98, 280, 94],
//    "genre": ["Fantasy", "Drama", "Adventure", "Fantasy"]
//]
//let table = try MLDataTable(dictionary: data)

// load data from CSV
//let csvURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/iris.csv")
//var table = try MLDataTable(contentsOf: csvURL)
//
//// table size
//table.size
//
//// column names
//table.columnNames
//
//// column types
//table.columnTypes
//
//// desc
//table.description
//
//// desc in playground
//table.playgroundDescription
//
//// get column by name
//table["species"]
//
//// filter out rows
//let setosaFilter = table["species", String.self]! != "setosa"
//let noSetosaTable = table[setosaFilter]
//
//// filter out rows example 2
//let speciesColumn = table["species"]
//let onlySetosa = table[speciesColumn == "setosa"]
//let noSetosa = table[speciesColumn != "setosa"]
//
//// split data randomly
//let (training, test) = table.randomSplit(by: 0.75)
//let (training1, test1) = table.randomSplit(by: 0.9, seed: 5)
//
//training.rows.count
//test.rows.count
//
//training1.rows.count
//test1.rows.count
//
//// derive new column from existing table data and add new column to the table back
//let columnName = "desc"
//let derivedColumn = table.map{
//    row -> String in
//    return String(format: "%@ %.1f", row["species"]!.stringValue!, row["sepal_width"]!.doubleValue!)
//}
//
//table.addColumn(derivedColumn, named: columnName)
//
//// remove column
//table.removeColumn(named: columnName)
//
//// get top rows
//print("------------- Top --------------")
//table.rows.prefix(5).forEach { row in
//    print(row)
//}
//
//// get bottom rows
//print("----------------Bottom --------------")
//table.rows.suffix(5).forEach { row in
//    print(row)
//}
//
//// drop missing value
//table.dropMissing()
//
//// drop duplicate values
//table.dropDuplicates()
//
//// fill missing values
//var i = 0
//let newDerivedColumn = table.map { row -> String? in
//    i = i + 1
//    if i % 2 == 0 {
//        return String(format: "%@ %.1f", row["species"]!.stringValue!, row["sepal_width"]!.doubleValue!)
//    }
//    return nil
//}
//
//table.addColumn(newDerivedColumn, named: "desc_missing")
////table.dropMissing()
//table.fillMissing(columnNamed: "desc_missing", with: MLDataValue.string("---------"))

// kaggle
//// ------------- Clasifier example ------------------
//import CreateML
//import Foundation
//
//// load data from the url
//let dataUrl = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/winequality-red.csv")
//// let dataUrl = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/winequality-white.csv")
//
//// load data into data table
//let table = try MLDataTable(contentsOf: dataUrl)
//
//// data split for training and test
//let (trainingSet, testSet) = table.randomSplit(by: 0.8, seed: 5)
//
//// classification
//let classifier = try MLClassifier(trainingData: table, targetColumn: "quality")
//
//// evaluate
//let evaluate = classifier.evaluation(on: testSet)
//
//print(evaluate)
//
//// save the classifier
////classifier.write(toFile: "", metadata: nil)

//// ------------- Regressor example ------------------
//import CreateML
//import Foundation
//
//// data url
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/boston.csv")
//
//// data table
//let table = try MLDataTable(contentsOf: dataURL)
//
//// split data into training and test sets
//let (trainingSet, testSet) = table.randomSplit(by: 0.8, seed: 0)
//
//// create regressor
//let regressor = try MLRegressor(trainingData: trainingSet, targetColumn: "PRICE")
//
//// evaluate
//let evaluate = regressor.evaluation(on: testSet)
//
//// print evaluation RMSE
//print(evaluate.rootMeanSquaredError)

// --------------- MLDecisionTreeClassifier --------------------
//import Foundation
//import CreateML
//
//let trainingURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/Titanic/train.csv")
//let testURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/Titanic/test.csv")
//
//var trainingTable = try MLDataTable(contentsOf: trainingURL)
//var testTable = try MLDataTable(contentsOf: testURL)
//
//trainingTable.removeColumn(named: "Ticket")
//testTable.removeColumn(named: "Ticket")
//
//let ageColumn = trainingTable["Age", Double.self]!
//let ageMask = ageColumn.mapMissing {
//    return $0 != nil
//}
//let newTrainingTable = trainingTable[ageMask]
//
//let titanicSurvivalClassifier = try MLDecisionTreeClassifier(trainingData: newTrainingTable, targetColumn: "Survived")
//
//let predictions = try titanicSurvivalClassifier.predictions(from: testTable)
//
//let passengerData = testTable["PassengerId", Int.self]!
//var predictionsTable = MLDataTable()
//predictionsTable.addColumn(passengerData, named: "PassengerId")
//predictionsTable.addColumn(predictions, named: "Survived")
//predictionsTable.rows.forEach { row in
//    let survived = row["Survived"]!.intValue! == 1 ? "survived." : "didn't survive."
//    print("Passenget id: \(row["PassengerId"]!.intValue!) \(survived)")
//}

// ---------------- MLLogisticRegressionClassifier --------------------
//import CreateML
//import Foundation
//// dataset url
//let trainingURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/Titanic/train.csv")
//let testURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/Titanic/test.csv")
//// data tables for dataset
//var trainingTable = try MLDataTable(contentsOf: trainingURL)
//var testTable = try MLDataTable(contentsOf: testURL)
//// drop missing values from data table
//trainingTable = trainingTable.dropMissing()
//testTable = testTable.dropMissing()
//// set training params
//let trainingParams = MLLogisticRegressionClassifier.ModelParameters(validationData: trainingTable, maxIterations: 100, l1Penalty: 8.0, l2Penalty: 0.0, stepSize: 4.0, convergenceThreshold: 0.01, featureRescaling: true)
//// create classifier
//let classifier = try MLLogisticRegressionClassifier(trainingData: trainingTable, targetColumn: "Survived", featureColumns: nil, parameters: trainingParams)
//// validation metrics
//let metrics = classifier.validationMetrics
//let evaluation = classifier.evaluation(on: testTable)
//// print metrics and evaluation precision recall
//print("---------------Metrics--------------")
//print(metrics)
//print("---------------Evaluation Precision Recall--------------")
//print(evaluation.precisionRecall)

//--------------------- MLRandomForestClassifier -----------------
//import CreateML
//import Foundation
//
//// data url
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/Mushrooms.csv")
//// convert data into data table
//let dataTable = try MLDataTable(contentsOf: dataURL)
//// split data into training and test set
//let (trainingSet, testSet) = dataTable.randomSplit(by: 0.8)
//// classification
//let randomForestClassifier = try MLRandomForestClassifier(trainingData: trainingSet, targetColumn: "class")
//// predictions
//let predictions = try randomForestClassifier.predictions(from: testSet)
//// predictions table
//var predictionTable = testSet
//predictionTable.addColumn(predictions, named: "predicted_class")
//// print predictions
//predictionTable.rows.forEach { row in
//    let habitat = row["habitat", String.self]!
//    let predictedClass = row["predicted_class", String.self]!
//    let actualClass = row["class", String.self]!
//    print("Habitat: \(habitat), Predicted class: \(predictedClass), Actual class: \(actualClass)")
//}


//--------------------- MLBoostedTreeClassifier -----------------
//import CreateML
//import Foundation
//// get data url
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/iris.csv")
//// load data into the data table from URL
//let table = try MLDataTable(contentsOf: dataURL)
//// split data into training and test set
//var (trainingSet, testSet) = table.randomSplit(by: 0.8)
//// remove dups
//trainingSet = trainingSet.dropDuplicates()
//testSet = testSet.dropDuplicates()
//// remove missing
//trainingSet = trainingSet.dropMissing()
//testSet = testSet.dropMissing()
//// classifier
//let boostedTreeClassifier = try MLBoostedTreeClassifier(trainingData: trainingSet, targetColumn: "species")
//// evaluate
//let evaluate = boostedTreeClassifier.evaluation(on: testSet)
//// confusion matrix
//print(evaluate.confusion)
//// prediction on test data set
//let predictions = try boostedTreeClassifier.predictions(from: testSet)
//// create a table for predictions
//var predictionTable = testSet
//predictionTable.addColumn(predictions, named: "predicted_species")
//// print row
//predictionTable.rows.forEach { row in
//    row.forEach({ (key, value) in
//        print("Key: \(key), Value: \(value)")
//    })
//    print("===========================================")
//}

//--------------------- MLSupportVectorClassifier -----------------
//import CreateML
//import Foundation
//
//// get data url
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/adult-income.csv")
//// load data table
//let table = try MLDataTable(contentsOf: dataURL)
//// split data into training and test sets
//var (trainingSet, testSet) = table.randomSplit(by: 0.8)
//// remove dups
//trainingSet = trainingSet.dropDuplicates()
//testSet = testSet.dropDuplicates()
//// remove missing
//trainingSet = trainingSet.dropMissing()
//testSet = testSet.dropMissing()
//// model params
//let params = MLSupportVectorClassifier.ModelParameters.init(validationData: trainingSet, maxIterations: 100, penalty: 8.0, convergenceThreshold: 0.01, featureRescaling: true)
//// build classifier
//let svmClassifier = try MLSupportVectorClassifier(trainingData: trainingSet, targetColumn: "income-level", featureColumns: nil, parameters: params)
//
//// validation metrics
//let metrics = svmClassifier.validationMetrics
//print(metrics)
//
//// evaluation
//let evaluation = svmClassifier.evaluation(on: testSet)
//print(evaluation.confusion)
//
//// predictions
//let predictions = try svmClassifier.predictions(from: testSet)
//var predictionTable = testSet
//predictionTable.addColumn(predictions, named: "predicted_income")
//predictionTable.rows.forEach { row in
//    row.forEach({ (key, value) in
//        print("Key: \(key), Value: \(value)")
//    })
//    print("==============================================")
//}

//--------------------- Regressors -----------------
//--------------------- MLBoostedTreeRegressor -----------------
//import Foundation
//import CreateML
//
//// get data url
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/bike_sharing_day.csv")
//// convert data into data table
//let table = try MLDataTable(contentsOf: dataURL)
//// split data into training and test
//let (trainingData, testData) = table.randomSplit(by: 0.8)
//// params for boosted tree
//let params = MLBoostedTreeRegressor.ModelParameters(validationData: trainingData, maxDepth: 10, maxIterations: 10, minLossReduction: 0, minChildWeight: 1, randomSeed: 0, stepSize: 0.3, earlyStoppingRounds: 50, rowSubsample: 0.5, columnSubsample: 1)
//// classifier
//let classifier = try MLBoostedTreeRegressor(trainingData: trainingData, targetColumn: "cnt", featureColumns: nil, parameters: params)
//// evaluation
//let evaluation = classifier.evaluation(on: testData)
//// print RMSE
//print(evaluation.rootMeanSquaredError)
//// print max error
//print(evaluation.maximumError)
//// predictions
//let predictions = try classifier.predictions(from: testData)
//var predictionTable = testData
//predictionTable.addColumn(predictions, named: "predicted_cnt_per_day")
//predictionTable.rows.forEach { row in
//    row.forEach({ (key, value) in
//        print("(\(key), \(value))")
//    })
//    print("========================================")
//}

//--------------------- MLLinearRegressor -----------------

//import Foundation
//import CreateML
//// get data url
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/sat.csv")
//// load data table
//let table = try MLDataTable(contentsOf: dataURL)
//// split data
//let (trainingSet, testSet) = table.randomSplit(by: 0.8)
//// params for linear regressor
//let params = MLLinearRegressor.ModelParameters.init(validationData: trainingSet, maxIterations: 100, l1Penalty: 8.0, l2Penalty: 0, stepSize: 4, convergenceThreshold: 0.01, featureRescaling: true)
//// regressor
//let linearRegressor = try MLLinearRegressor(trainingData: trainingSet, targetColumn: "univ_GPA", featureColumns: nil, parameters: params)
//// evaluate
//let evaluation = linearRegressor.evaluation(on: testSet)
//print(evaluation.rootMeanSquaredError)
//print(evaluation.maximumError)
//// predictions
//let predictions = try linearRegressor.predictions(from: testSet)
//var predictionsTable = testSet
//predictionsTable.addColumn(predictions, named: "predicted_GPA")
//predictionsTable.rows.forEach { row in
//    row.forEach({ (key, value) in
//        print("(\(key), \(value))")
//    })
//    print("================================")
//}

//--------------------- MLDecisionTreeRegressor -----------------
//import Foundation
//import CreateML
//
//// get data
//let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/sat.csv")
//// load data into table
//let table = try MLDataTable(contentsOf: dataURL)
//// split data
//let (trainingSet, testSet) = table.randomSplit(by: 0.8)
//// params
//let params = MLDecisionTreeRegressor.ModelParameters.init(validationData: trainingSet, maxDepth: 6, minLossReduction: 0, minChildWeight: 10, randomSeed: 0)
//// regressor
//let regressor = try MLDecisionTreeRegressor(trainingData: trainingSet, targetColumn: "univ_GPA", featureColumns: nil, parameters: params)
//// evaluate
//let evaluation = regressor.evaluation(on: testSet)
//print(evaluation.rootMeanSquaredError)
//// predictions
//let predictions = try regressor.predictions(from: testSet)
//var predictionTable = testSet
//predictionTable.addColumn(predictions, named: "predicted_GPA")
//predictionTable.rows.forEach { row in
//    row.forEach({ (key, value) in
//        print("(\(key), \(value))")
//    })
//    print("===========================")
//}

//--------------------- MLRandomForestRegressor -----------------
import Foundation
import CreateML

// get data
let dataURL = URL(fileURLWithPath: "/Users/Shared/ML/TextClassifier/DataSets/bike_sharing_hour.csv")
// load table
let table = try MLDataTable(contentsOf: dataURL)
// split data
let (trainingData, testData) = table.randomSplit(by: 0.8)
// regressor
let regressor = try MLRandomForestRegressor(trainingData: trainingData, targetColumn: "cnt")
// evaluation
let evaluation = regressor.evaluation(on: testData)
// print RMSE
print(evaluation.rootMeanSquaredError)
// prediction
let predictions = try regressor.predictions(from: testData)
var predictionsTable = testData
predictionsTable.addColumn(predictions, named: "predicted_cnt")
predictionsTable.rows.forEach { row in
    row.forEach({ (key, value) in
        print("(\(key),\(value))")
    })
    print("===========================")
}

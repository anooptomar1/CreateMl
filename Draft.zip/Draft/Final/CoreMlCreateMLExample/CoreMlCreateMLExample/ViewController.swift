//
// ViewController
// CoreMlCreateMLExample
//
// Created by DevTechie Interactive on 10/12/18.
// Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit
import CoreML
import Vision

class ViewController: UIViewController {
    
    @IBOutlet weak var imageV: UIImageView!
    @IBOutlet weak var resultLabel: UILabel!
    
    lazy var classificationRequest: VNCoreMLRequest = {
        let model = try! VNCoreMLModel(for: ImageClassifier().model)
        let request = VNCoreMLRequest(model: model, completionHandler: { (request:VNRequest, error:Error?) in
            self.processImageForClassification(request: request, error: error)
        })
        request.imageCropAndScaleOption = .centerCrop
        return request
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func didPressProcessImage(_ sender: UIButton) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
    }

    func processImageForClassification(request: VNRequest, error: Error?) {
        guard let results = request.results, let classfications = results as? [VNClassificationObservation] else {
            print("Unbale to process classification request")
            return
        }
        if classfications.isEmpty {
            print("No Results")
        } else {
            let topClassifications = classfications.prefix(2)
            let desc = topClassifications.map { classification in
                return String(format: " (%.2f) %@", classification.confidence, classification.identifier)
            }
            DispatchQueue.main.async {
                self.resultLabel.text = desc.joined(separator: "\n")
            }
        }
    }
    
    func performClassification(image: UIImage) {
        guard let ciImage = CIImage(image: image) else {
            print("Unable to convert image to CIImage")
            return
        }
        DispatchQueue.global(qos: DispatchQoS.QoSClass.userInitiated).async {
            let handler = VNImageRequestHandler(ciImage: ciImage, options: [:])
            do {
                try handler.perform([self.classificationRequest])
            }catch {
                print("\(error.localizedDescription)")
            }
        }
    }
    
}

extension ViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        picker.dismiss(animated: true, completion: nil)
        
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            self.imageV.image = image
            self.performClassification(image: image)
        }
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}

